# babel-helper-explode-class

## Usage

TODO
